public class Battleships {
    private int id;
    private int length;

    public Battleships(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
    public int getLength() {
        return length;
    }
}
