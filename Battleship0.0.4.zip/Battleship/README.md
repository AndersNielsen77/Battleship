# Battleship
> Wonderful Battleship game (1 vs 1) 

![](header.png)

## Release History
* 0.0.2
    * Your turn button (Changing color)
    * Chat size
    * Executable jar files for Client and server
    * Connect changes to Connecting.. and Connected
* 0.0.1
    * Work in progress
    
## Work in progress                                            
1. Forminsk chat i Ship placement samt skipe tekst.
2. Fjerne to ekstra ships placement når man har supmit.
3. Skriv i Battlefield om man har ramt.
4. Auto scroll både battlefield og ships placement.
5. Ny din tur knap (Skrifter farve). (DONE)
6. Skibe bliver rød når de er døde.
7. Skal sætte alle skipe i ships placement.
8. Tilføje sidste skip nr 4. (Submarine) size 3.
9. Quit og Return to menu på Ship placement fix.
10. Quit og Return to menu lukker alle threds og JFrame's
11. Overveje preformance, inf loop, måske lave nogle bake/timeout på serveren for undgå overbelastning.
12. Automatisk IP.
    
## Meta

1. Anders Nielsen – s194299@student.dtu.dk 
2. Mikkel Randrup Rahbek - s194298@student.dtu.dk 
3. Mads Ptak - s194297@student.dtu.dk  
